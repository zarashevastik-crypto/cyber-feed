import { Router, type IRouter, type Request, type Response } from "express";
import { desc, eq } from "drizzle-orm";
import { db, usersTable } from "@workspace/db";
import { ListUsersResponse, SendPresenceHeartbeatResponse } from "@workspace/api-zod";
import { displayName } from "../lib/displayName";

const router: IRouter = Router();
const ONLINE_WINDOW_MS = 2 * 60 * 1000;

router.get("/users", async (req: Request, res: Response): Promise<void> => {
  const rows = await db.select().from(usersTable).orderBy(desc(usersTable.lastSeenAt));
  const now = Date.now();
  const users = rows
    .filter((u) => !req.user || u.id !== req.user.id)
    .map((u) => ({
      id: u.id,
      displayName: displayName(u),
      avatarUrl: u.profileImageUrl,
      isOnline: u.lastSeenAt ? now - u.lastSeenAt.getTime() < ONLINE_WINDOW_MS : false,
      lastSeenAt: u.lastSeenAt,
    }));
  res.json(ListUsersResponse.parse(users));
});

router.post("/presence/heartbeat", async (req: Request, res: Response): Promise<void> => {
  if (!req.isAuthenticated()) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  await db.update(usersTable).set({ lastSeenAt: new Date() }).where(eq(usersTable.id, req.user.id));
  res.json(SendPresenceHeartbeatResponse.parse({ success: true }));
});

export default router;
