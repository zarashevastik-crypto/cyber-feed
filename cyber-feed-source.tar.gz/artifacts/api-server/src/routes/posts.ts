import { Router, type IRouter, type Request, type Response } from "express";
import { and, desc, eq, ilike, inArray, or, sql } from "drizzle-orm";
import { db, postsTable, commentsTable, likesTable, usersTable, notificationsTable } from "@workspace/db";
import {
  ListPostsQueryParams,
  ListPostsResponse,
  CreatePostBody,
  CreatePostResponse,
  DeletePostParams,
  TogglePostLikeParams,
  TogglePostLikeResponse,
  ListCommentsParams,
  ListCommentsResponse,
  CreateCommentParams,
  CreateCommentBody,
  CreateCommentResponse,
  DeleteCommentParams,
  GetTrendingHashtagsResponse,
} from "@workspace/api-zod";
import { displayName } from "../lib/displayName";

const router: IRouter = Router();

async function serializePosts(postIds: number[], viewerId: string | undefined) {
  if (postIds.length === 0) return [];

  const rows = await db
    .select({
      id: postsTable.id,
      authorId: postsTable.authorId,
      content: postsTable.content,
      imageUrl: postsTable.imageUrl,
      createdAt: postsTable.createdAt,
      authorFirstName: usersTable.firstName,
      authorLastName: usersTable.lastName,
      authorEmail: usersTable.email,
      authorAvatarUrl: usersTable.profileImageUrl,
    })
    .from(postsTable)
    .innerJoin(usersTable, eq(postsTable.authorId, usersTable.id))
    .where(inArray(postsTable.id, postIds));

  const likeCounts = await db
    .select({ postId: likesTable.postId, count: sql<number>`count(*)::int` })
    .from(likesTable)
    .where(inArray(likesTable.postId, postIds))
    .groupBy(likesTable.postId);

  const commentCounts = await db
    .select({ postId: commentsTable.postId, count: sql<number>`count(*)::int` })
    .from(commentsTable)
    .where(inArray(commentsTable.postId, postIds))
    .groupBy(commentsTable.postId);

  let likedPostIds = new Set<number>();
  if (viewerId) {
    const liked = await db
      .select({ postId: likesTable.postId })
      .from(likesTable)
      .where(and(inArray(likesTable.postId, postIds), eq(likesTable.userId, viewerId)));
    likedPostIds = new Set(liked.map((l) => l.postId));
  }

  const likeMap = new Map(likeCounts.map((l) => [l.postId, l.count]));
  const commentMap = new Map(commentCounts.map((c) => [c.postId, c.count]));
  const byId = new Map(rows.map((r) => [r.id, r]));

  return postIds
    .map((id) => byId.get(id))
    .filter((r): r is (typeof rows)[number] => r != null)
    .map((r) => ({
      id: r.id,
      authorId: r.authorId,
      authorName: displayName({
        firstName: r.authorFirstName,
        lastName: r.authorLastName,
        email: r.authorEmail,
      }),
      authorAvatarUrl: r.authorAvatarUrl,
      content: r.content,
      imageUrl: r.imageUrl,
      likesCount: likeMap.get(r.id) ?? 0,
      likedByMe: likedPostIds.has(r.id),
      commentsCount: commentMap.get(r.id) ?? 0,
      createdAt: r.createdAt,
    }));
}

router.get("/posts", async (req: Request, res: Response): Promise<void> => {
  const parsedQuery = ListPostsQueryParams.safeParse(req.query);
  if (!parsedQuery.success) {
    res.status(400).json({ error: parsedQuery.error.message });
    return;
  }
  const { search } = parsedQuery.data;

  let idRows: { id: number }[];
  if (search && search.trim()) {
    const term = `%${search.trim()}%`;
    idRows = await db
      .select({ id: postsTable.id })
      .from(postsTable)
      .innerJoin(usersTable, eq(postsTable.authorId, usersTable.id))
      .where(
        or(
          ilike(postsTable.content, term),
          ilike(usersTable.firstName, term),
          ilike(usersTable.lastName, term),
        ),
      )
      .orderBy(desc(postsTable.createdAt))
      .limit(100);
  } else {
    idRows = await db
      .select({ id: postsTable.id })
      .from(postsTable)
      .orderBy(desc(postsTable.createdAt))
      .limit(100);
  }

  const posts = await serializePosts(idRows.map((r) => r.id), req.user?.id);
  res.json(ListPostsResponse.parse(posts));
});

router.post("/posts", async (req: Request, res: Response): Promise<void> => {
  if (!req.isAuthenticated()) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  const parsed = CreatePostBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  if (!parsed.data.content.trim() && !parsed.data.imageUrl) {
    res.status(400).json({ error: "Post must have content or an image" });
    return;
  }

  const [post] = await db
    .insert(postsTable)
    .values({
      authorId: req.user.id,
      content: parsed.data.content,
      imageUrl: parsed.data.imageUrl ?? null,
    })
    .returning();

  const [serialized] = await serializePosts([post.id], req.user.id);
  res.status(201).json(CreatePostResponse.parse(serialized));
});

router.delete("/posts/:id", async (req: Request, res: Response): Promise<void> => {
  if (!req.isAuthenticated()) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  const params = DeletePostParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [post] = await db.select().from(postsTable).where(eq(postsTable.id, params.data.id));
  if (!post) {
    res.status(404).json({ error: "Post not found" });
    return;
  }
  if (post.authorId !== req.user.id) {
    res.status(403).json({ error: "Not the author" });
    return;
  }

  await db.delete(postsTable).where(eq(postsTable.id, params.data.id));
  res.sendStatus(204);
});

router.post("/posts/:id/like", async (req: Request, res: Response): Promise<void> => {
  if (!req.isAuthenticated()) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  const params = TogglePostLikeParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [post] = await db.select().from(postsTable).where(eq(postsTable.id, params.data.id));
  if (!post) {
    res.status(404).json({ error: "Post not found" });
    return;
  }

  const [existing] = await db
    .select()
    .from(likesTable)
    .where(and(eq(likesTable.postId, post.id), eq(likesTable.userId, req.user.id)));

  if (existing) {
    await db.delete(likesTable).where(eq(likesTable.id, existing.id));
  } else {
    await db.insert(likesTable).values({ postId: post.id, userId: req.user.id });
    if (post.authorId !== req.user.id) {
      await db.insert(notificationsTable).values({
        userId: post.authorId,
        fromUserId: req.user.id,
        type: "like",
        text: "liked your post",
      });
    }
  }

  const [serialized] = await serializePosts([post.id], req.user.id);
  res.json(TogglePostLikeResponse.parse(serialized));
});

router.get("/posts/:id/comments", async (req: Request, res: Response): Promise<void> => {
  const params = ListCommentsParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [post] = await db.select().from(postsTable).where(eq(postsTable.id, params.data.id));
  if (!post) {
    res.status(404).json({ error: "Post not found" });
    return;
  }

  const rows = await db
    .select({
      id: commentsTable.id,
      postId: commentsTable.postId,
      authorId: commentsTable.authorId,
      text: commentsTable.text,
      createdAt: commentsTable.createdAt,
      authorFirstName: usersTable.firstName,
      authorLastName: usersTable.lastName,
      authorEmail: usersTable.email,
    })
    .from(commentsTable)
    .innerJoin(usersTable, eq(commentsTable.authorId, usersTable.id))
    .where(eq(commentsTable.postId, post.id))
    .orderBy(commentsTable.createdAt);

  const comments = rows.map((r) => ({
    id: r.id,
    postId: r.postId,
    authorId: r.authorId,
    authorName: displayName({
      firstName: r.authorFirstName,
      lastName: r.authorLastName,
      email: r.authorEmail,
    }),
    text: r.text,
    createdAt: r.createdAt,
  }));
  res.json(ListCommentsResponse.parse(comments));
});

router.post("/posts/:id/comments", async (req: Request, res: Response): Promise<void> => {
  if (!req.isAuthenticated()) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  const params = CreateCommentParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const parsed = CreateCommentBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [post] = await db.select().from(postsTable).where(eq(postsTable.id, params.data.id));
  if (!post) {
    res.status(404).json({ error: "Post not found" });
    return;
  }

  const [comment] = await db
    .insert(commentsTable)
    .values({ postId: post.id, authorId: req.user.id, text: parsed.data.text })
    .returning();

  if (post.authorId !== req.user.id) {
    await db.insert(notificationsTable).values({
      userId: post.authorId,
      fromUserId: req.user.id,
      type: "comment",
      text: "commented on your post",
    });
  }

  res.status(201).json(
    CreateCommentResponse.parse({
      id: comment.id,
      postId: comment.postId,
      authorId: comment.authorId,
      authorName: displayName(req.user),
      text: comment.text,
      createdAt: comment.createdAt,
    }),
  );
});

router.delete("/comments/:id", async (req: Request, res: Response): Promise<void> => {
  if (!req.isAuthenticated()) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  const params = DeleteCommentParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [comment] = await db.select().from(commentsTable).where(eq(commentsTable.id, params.data.id));
  if (!comment) {
    res.status(404).json({ error: "Comment not found" });
    return;
  }
  if (comment.authorId !== req.user.id) {
    res.status(403).json({ error: "Not the author" });
    return;
  }

  await db.delete(commentsTable).where(eq(commentsTable.id, params.data.id));
  res.sendStatus(204);
});

router.get("/feed/trending-hashtags", async (_req: Request, res: Response): Promise<void> => {
  const rows = await db
    .select({ content: postsTable.content })
    .from(postsTable)
    .orderBy(desc(postsTable.createdAt))
    .limit(200);

  const counts = new Map<string, number>();
  const hashtagRegex = /#[\p{L}\p{N}_]+/gu;
  for (const row of rows) {
    const matches = row.content.match(hashtagRegex) ?? [];
    for (const tag of matches) {
      const normalized = tag.toLowerCase();
      counts.set(normalized, (counts.get(normalized) ?? 0) + 1);
    }
  }

  const trending = Array.from(counts.entries())
    .map(([tag, count]) => ({ tag, count }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 10);

  res.json(GetTrendingHashtagsResponse.parse(trending));
});

export default router;
