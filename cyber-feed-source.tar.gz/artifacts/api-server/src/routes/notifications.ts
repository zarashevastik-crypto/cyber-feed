import { Router, type IRouter, type Request, type Response } from "express";
import { and, desc, eq } from "drizzle-orm";
import { db, notificationsTable, usersTable } from "@workspace/db";
import { ListNotificationsResponse, ClearNotificationsResponse } from "@workspace/api-zod";
import { displayName } from "../lib/displayName";

const router: IRouter = Router();

router.get("/notifications", async (req: Request, res: Response): Promise<void> => {
  if (!req.isAuthenticated()) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }

  const rows = await db
    .select({
      id: notificationsTable.id,
      type: notificationsTable.type,
      text: notificationsTable.text,
      read: notificationsTable.read,
      createdAt: notificationsTable.createdAt,
      fromUserId: notificationsTable.fromUserId,
      fromFirstName: usersTable.firstName,
      fromLastName: usersTable.lastName,
      fromEmail: usersTable.email,
    })
    .from(notificationsTable)
    .innerJoin(usersTable, eq(notificationsTable.fromUserId, usersTable.id))
    .where(eq(notificationsTable.userId, req.user.id))
    .orderBy(desc(notificationsTable.createdAt))
    .limit(50);

  const notifications = rows.map((r) => ({
    id: r.id,
    fromUserId: r.fromUserId,
    fromUserName: displayName({ firstName: r.fromFirstName, lastName: r.fromLastName, email: r.fromEmail }),
    type: r.type as "like" | "comment" | "message",
    text: r.text,
    createdAt: r.createdAt,
    read: r.read,
  }));
  res.json(ListNotificationsResponse.parse(notifications));
});

router.delete("/notifications", async (req: Request, res: Response): Promise<void> => {
  if (!req.isAuthenticated()) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }

  await db
    .update(notificationsTable)
    .set({ read: true })
    .where(and(eq(notificationsTable.userId, req.user.id), eq(notificationsTable.read, false)));

  res.json(ClearNotificationsResponse.parse({ success: true }));
});

export default router;
