import { Router, type IRouter, type Request, type Response } from "express";
import { and, desc, eq, inArray, or } from "drizzle-orm";
import { db, directMessagesTable, notificationsTable, usersTable } from "@workspace/db";
import {
  ListDirectMessagesParams,
  ListDirectMessagesResponse,
  SendDirectMessageParams,
  SendDirectMessageBody,
  SendDirectMessageResponse,
  ListConversationsResponse,
} from "@workspace/api-zod";
import { displayName } from "../lib/displayName";

const router: IRouter = Router();
const ONLINE_WINDOW_MS = 2 * 60 * 1000;

router.get("/dm/conversations", async (req: Request, res: Response): Promise<void> => {
  if (!req.isAuthenticated()) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  const myId = req.user.id;

  const rows = await db
    .select()
    .from(directMessagesTable)
    .where(or(eq(directMessagesTable.senderId, myId), eq(directMessagesTable.recipientId, myId)))
    .orderBy(desc(directMessagesTable.createdAt));

  const byPartner = new Map<string, (typeof rows)[number]>();
  for (const row of rows) {
    const partnerId = row.senderId === myId ? row.recipientId : row.senderId;
    if (!byPartner.has(partnerId)) byPartner.set(partnerId, row);
  }

  const partnerIds = Array.from(byPartner.keys());
  if (partnerIds.length === 0) {
    res.json(ListConversationsResponse.parse([]));
    return;
  }

  const users = await db.select().from(usersTable).where(inArray(usersTable.id, partnerIds));
  const userMap = new Map(users.map((u) => [u.id, u]));
  const now = Date.now();

  const conversations = partnerIds
    .map((partnerId) => {
      const u = userMap.get(partnerId);
      if (!u) return null;
      const last = byPartner.get(partnerId)!;
      return {
        user: {
          id: u.id,
          displayName: displayName(u),
          avatarUrl: u.profileImageUrl,
          isOnline: u.lastSeenAt ? now - u.lastSeenAt.getTime() < ONLINE_WINDOW_MS : false,
          lastSeenAt: u.lastSeenAt,
        },
        lastMessage: {
          id: last.id,
          senderId: last.senderId,
          recipientId: last.recipientId,
          text: last.text,
          createdAt: last.createdAt,
        },
        unreadCount: 0,
      };
    })
    .filter((c): c is NonNullable<typeof c> => c != null);

  res.json(ListConversationsResponse.parse(conversations));
});

router.get("/dm/:userId", async (req: Request, res: Response): Promise<void> => {
  if (!req.isAuthenticated()) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  const params = ListDirectMessagesParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const myId = req.user.id;
  const otherId = params.data.userId;

  const rows = await db
    .select()
    .from(directMessagesTable)
    .where(
      or(
        and(eq(directMessagesTable.senderId, myId), eq(directMessagesTable.recipientId, otherId)),
        and(eq(directMessagesTable.senderId, otherId), eq(directMessagesTable.recipientId, myId)),
      ),
    )
    .orderBy(directMessagesTable.createdAt);

  res.json(ListDirectMessagesResponse.parse(rows));
});

router.post("/dm/:userId", async (req: Request, res: Response): Promise<void> => {
  if (!req.isAuthenticated()) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  const params = SendDirectMessageParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const parsed = SendDirectMessageBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [message] = await db
    .insert(directMessagesTable)
    .values({ senderId: req.user.id, recipientId: params.data.userId, text: parsed.data.text })
    .returning();

  if (params.data.userId !== req.user.id) {
    await db.insert(notificationsTable).values({
      userId: params.data.userId,
      fromUserId: req.user.id,
      type: "message",
      text: "sent you a message",
    });
  }

  res.status(201).json(SendDirectMessageResponse.parse(message));
});

export default router;
