import { Switch, Route, Router as WouterRouter, Redirect } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import { useAuth } from "@workspace/replit-auth-web";
import { Loader2 } from "lucide-react";
import React from "react";

import Feed from "./pages/feed";
import PostDetail from "./pages/post";
import People from "./pages/people";
import Profile from "./pages/profile";
import Messages from "./pages/messages";
import Notifications from "./pages/notifications";

function Landing() {
  const { login } = useAuth();
  return (
    <div className="min-h-screen w-full flex flex-col items-center justify-center bg-background relative overflow-hidden">
      <div className="absolute inset-0 z-0 opacity-20 pointer-events-none" style={{ backgroundImage: 'radial-gradient(circle at center, var(--primary) 0%, transparent 40%)' }} />
      
      <div className="z-10 text-center space-y-8 p-8 border border-primary/50 bg-background/80 backdrop-blur">
        <h1 className="text-6xl font-display font-bold text-primary glitch-text" data-text="CYBER FEED">CYBER FEED</h1>
        <p className="text-foreground max-w-md mx-auto text-lg font-mono">
          [ NEON SIGNALS IN THE DARK. CONNECT TO THE NETWORK. ]
        </p>
        <button 
          onClick={login}
          className="hover-glitch bg-primary text-primary-foreground px-8 py-4 font-bold text-xl uppercase tracking-widest border border-primary hover:bg-transparent hover:text-primary transition-colors font-mono mt-8"
        >
          [ INITIATE CONNECTION ]
        </button>
      </div>
    </div>
  );
}

function Layout({ children }: { children: React.ReactNode }) {
  const { logout, user } = useAuth();

  return (
    <div className="flex h-screen bg-background overflow-hidden">
      <div className="w-64 border-r border-border p-4 flex flex-col gap-4 bg-card/30">
        <h2 className="text-2xl font-display font-bold text-primary mb-8 tracking-widest text-center mt-4">CYBER_FEED</h2>
        <div className="flex flex-col gap-2 font-mono text-sm tracking-wider">
           <a href="/" className="px-4 py-2 hover:bg-primary/10 hover:text-primary transition-colors border-l-2 border-transparent hover:border-primary">/feed</a>
           <a href="/notifications" className="px-4 py-2 hover:bg-primary/10 hover:text-primary transition-colors border-l-2 border-transparent hover:border-primary">/notifications</a>
           <a href="/messages" className="px-4 py-2 hover:bg-primary/10 hover:text-primary transition-colors border-l-2 border-transparent hover:border-primary">/messages</a>
           <a href="/people" className="px-4 py-2 hover:bg-primary/10 hover:text-primary transition-colors border-l-2 border-transparent hover:border-primary">/people</a>
           {user && <a href={`/profile/${user.id}`} className="px-4 py-2 hover:bg-primary/10 hover:text-primary transition-colors border-l-2 border-transparent hover:border-primary">/profile</a>}
        </div>
        <div className="mt-auto">
          <div className="flex items-center gap-3 p-4 border border-border bg-background mb-4">
             <div className="w-8 h-8 bg-muted flex items-center justify-center text-primary font-bold">{user?.firstName?.[0] || 'U'}</div>
             <div className="text-xs truncate text-foreground">{user?.firstName}</div>
          </div>
          <button onClick={logout} className="w-full text-left px-4 py-2 text-xs font-mono text-muted-foreground hover:text-destructive transition-colors">
            [ TERMINATE SESSION ]
          </button>
        </div>
      </div>
      <div className="flex-1 overflow-y-auto relative">
        <div className="absolute inset-0 z-0 opacity-5 pointer-events-none" style={{ backgroundImage: 'repeating-linear-gradient(0deg, transparent, transparent 1px, var(--primary) 1px, var(--primary) 2px)', backgroundSize: '100% 4px' }} />
        <div className="relative z-10 p-8 h-full overflow-y-auto">
          {children}
        </div>
      </div>
    </div>
  );
}

function ProtectedRoute({ component: Component }: { component: React.ComponentType }) {
  const { isAuthenticated, isLoading } = useAuth();

  if (isLoading) {
    return <div className="h-screen w-full flex items-center justify-center bg-background"><Loader2 className="animate-spin text-primary w-12 h-12" /></div>;
  }

  if (!isAuthenticated) {
    return <Redirect to="/login" />;
  }

  return (
    <Layout>
      <Component />
    </Layout>
  );
}

function Router() {
  return (
    <Switch>
      <Route path="/login" component={Landing} />
      <Route path="/">
        <ProtectedRoute component={Feed} />
      </Route>
      <Route path="/post/:id">
        <ProtectedRoute component={PostDetail} />
      </Route>
      <Route path="/profile/:id">
        <ProtectedRoute component={Profile} />
      </Route>
      <Route path="/messages">
        <ProtectedRoute component={Messages} />
      </Route>
      <Route path="/notifications">
        <ProtectedRoute component={Notifications} />
      </Route>
      <Route path="/people">
        <ProtectedRoute component={People} />
      </Route>
      <Route component={NotFound} />
    </Switch>
  );
}

const queryClient = new QueryClient();

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
