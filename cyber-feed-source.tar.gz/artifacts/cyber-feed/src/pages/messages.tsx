import { useState } from "react";
import { useLocation } from "wouter";
import { useQueryClient } from "@tanstack/react-query";
import {
  useListConversations,
  useListDirectMessages,
  useSendDirectMessage,
  useGetCurrentAuthUser,
  useListUsers,
  getListDirectMessagesQueryKey,
  getListConversationsQueryKey,
} from "@workspace/api-client-react";

export default function Messages() {
  const [location] = useLocation();
  const params = new URLSearchParams(location.split("?")[1] ?? "");
  const [activeUserId, setActiveUserId] = useState<string | null>(params.get("to"));
  const [text, setText] = useState("");
  const queryClient = useQueryClient();

  const { data: currentUser } = useGetCurrentAuthUser();
  const { data: conversations, isLoading: loadingConversations } = useListConversations();
  const { data: allUsers } = useListUsers();

  const activePartner =
    conversations?.find((c) => c.user.id === activeUserId)?.user ??
    allUsers?.find((u) => u.id === activeUserId) ??
    null;

  const { data: messages, isLoading: loadingMessages } = useListDirectMessages(activeUserId ?? "", {
    query: { queryKey: getListDirectMessagesQueryKey(activeUserId ?? ""), enabled: !!activeUserId },
  });

  const sendMessage = useSendDirectMessage({
    mutation: {
      onSuccess: () => {
        if (activeUserId) {
          queryClient.invalidateQueries({ queryKey: getListDirectMessagesQueryKey(activeUserId) });
        }
        queryClient.invalidateQueries({ queryKey: getListConversationsQueryKey() });
      },
    },
  });

  const handleSend = () => {
    if (!text.trim() || !activeUserId) return;
    sendMessage.mutate(
      { userId: activeUserId, data: { text: text.trim() } },
      { onSuccess: () => setText("") },
    );
  };

  return (
    <div className="max-w-5xl mx-auto h-full flex flex-col">
      <h2 className="text-2xl font-display text-primary mb-8 shrink-0">[ SECURE CHANNELS ]</h2>
      <div className="flex-1 grid grid-cols-3 gap-6 min-h-0">
        <div className="col-span-1 border border-border bg-card flex flex-col">
          <div className="p-4 border-b border-border text-secondary font-mono text-sm">/ ACTIVE THREADS</div>
          <div className="flex-1 overflow-y-auto p-2">
            {loadingConversations ? (
              <div className="text-primary animate-pulse font-mono text-sm p-4">[ LOADING... ]</div>
            ) : conversations?.length === 0 ? (
              <div className="text-muted-foreground font-mono text-sm p-4">[ NO ACTIVE CHANNELS ]</div>
            ) : (
              conversations?.map((c) => (
                <button
                  key={c.user.id}
                  onClick={() => setActiveUserId(c.user.id)}
                  className={`w-full text-left p-3 mb-1 border transition-colors flex items-center gap-3 ${activeUserId === c.user.id ? "border-primary bg-primary/10" : "border-transparent hover:border-border"}`}
                >
                  <div className="w-8 h-8 bg-muted border border-border flex items-center justify-center text-primary font-bold text-xs overflow-hidden shrink-0">
                    {c.user.avatarUrl ? (
                      <img src={c.user.avatarUrl} alt="" className="w-full h-full object-cover" />
                    ) : (
                      c.user.displayName[0]
                    )}
                  </div>
                  <div className="min-w-0">
                    <div className="text-sm font-bold text-foreground truncate">{c.user.displayName}</div>
                    <div className="text-xs text-muted-foreground truncate font-mono">
                      {c.lastMessage?.text ?? "..."}
                    </div>
                  </div>
                  {c.unreadCount > 0 && (
                    <span className="ml-auto text-xs bg-primary text-primary-foreground px-1.5 rounded-full shrink-0">
                      {c.unreadCount}
                    </span>
                  )}
                </button>
              ))
            )}
          </div>
        </div>

        <div className="col-span-2 border border-primary/30 bg-background flex flex-col relative overflow-hidden">
          <div className="p-4 border-b border-border flex justify-between items-center bg-card/50">
            <span className="font-mono text-sm text-foreground">
              {activePartner ? `[ CHANNEL : ${activePartner.displayName} ]` : "[ SELECT A CHANNEL TO DECRYPT ]"}
            </span>
          </div>
          <div className="flex-1 overflow-y-auto p-6 flex flex-col gap-3 justify-end">
            {!activeUserId ? (
              <div className="text-center text-muted-foreground font-mono text-sm">[ ENCRYPTED SILENCE ]</div>
            ) : loadingMessages ? (
              <div className="text-center text-primary animate-pulse font-mono text-sm">[ DECRYPTING... ]</div>
            ) : messages?.length === 0 ? (
              <div className="text-center text-muted-foreground font-mono text-sm">[ NO MESSAGES YET ]</div>
            ) : (
              messages?.map((m) => {
                const mine = m.senderId === currentUser?.user?.id;
                return (
                  <div key={m.id} className={`max-w-[70%] ${mine ? "self-end text-right" : "self-start"}`}>
                    <div
                      className={`p-3 font-mono text-sm border ${mine ? "border-primary/50 bg-primary/10 text-foreground" : "border-border bg-card text-foreground"}`}
                    >
                      {m.text}
                    </div>
                    <div className="text-xs text-muted-foreground mt-1">
                      {new Date(m.createdAt).toLocaleTimeString()}
                    </div>
                  </div>
                );
              })
            )}
          </div>
          <div className="p-4 border-t border-border bg-card/50 flex gap-2">
            <input
              disabled={!activeUserId}
              type="text"
              className="w-full bg-input border border-border p-3 text-foreground focus:border-primary outline-none transition-colors font-mono disabled:opacity-50"
              placeholder={activeUserId ? "Type a message..." : "Awaiting connection..."}
              value={text}
              onChange={(e) => setText(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleSend()}
            />
            <button
              onClick={handleSend}
              disabled={!activeUserId || !text.trim() || sendMessage.isPending}
              className="bg-primary text-primary-foreground px-4 font-bold hover:bg-primary/80 disabled:opacity-40 shrink-0"
            >
              SEND
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
