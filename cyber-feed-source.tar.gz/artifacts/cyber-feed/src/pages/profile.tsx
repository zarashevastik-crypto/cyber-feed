import { Link, useParams } from "wouter";
import {
  useListUsers,
  useListPosts,
  useGetCurrentAuthUser,
} from "@workspace/api-client-react";

export default function Profile() {
  const { id } = useParams();
  const { data: currentUser } = useGetCurrentAuthUser();
  const { data: users, isLoading: loadingUsers } = useListUsers();
  const { data: posts, isLoading: loadingPosts } = useListPosts();

  const user = users?.find((u) => u.id === id);
  const userPosts = posts?.filter((p) => p.authorId === id) ?? [];
  const isMe = currentUser?.user?.id === id;

  if (loadingUsers) {
    return <div className="text-primary animate-pulse font-mono">[ LOADING PROFILE... ]</div>;
  }

  if (!user) {
    return <div className="text-muted-foreground font-mono">[ USER NOT FOUND ]</div>;
  }

  return (
    <div className="max-w-3xl mx-auto">
      <h2 className="text-2xl font-display text-primary mb-8">[ USER PROFILE ]</h2>
      <div className="border border-border p-8 bg-card">
        <div className="flex items-center gap-6 mb-8">
          <div className="w-24 h-24 bg-muted border-2 border-primary flex items-center justify-center text-primary font-display text-4xl overflow-hidden">
            {user.avatarUrl ? (
              <img src={user.avatarUrl} alt="" className="w-full h-full object-cover" />
            ) : (
              user.displayName[0]
            )}
          </div>
          <div className="flex-1">
            <h3 className="text-3xl font-display text-foreground mb-2">{user.displayName}</h3>
            <div className={`text-sm font-mono ${user.isOnline ? "text-primary" : "text-muted-foreground"}`}>
              {user.isOnline
                ? "[ STATUS : ONLINE ]"
                : user.lastSeenAt
                  ? `[ LAST SEEN : ${new Date(user.lastSeenAt).toLocaleString()} ]`
                  : "[ STATUS : OFFLINE ]"}
            </div>
          </div>
          {!isMe && (
            <Link
              href={`/messages?to=${user.id}`}
              className="bg-secondary text-secondary-foreground px-4 py-2 font-bold hover:bg-secondary/80 shrink-0"
            >
              MESSAGE
            </Link>
          )}
        </div>
        <div className="border-t border-border pt-8">
          <h4 className="text-xl font-display text-secondary mb-4">/ RECENT TRANSMISSIONS</h4>
          {loadingPosts ? (
            <div className="text-primary animate-pulse font-mono text-sm">[ LOADING... ]</div>
          ) : userPosts.length === 0 ? (
            <div className="text-muted-foreground font-mono text-sm">[ END OF SIGNAL ]</div>
          ) : (
            <div className="space-y-4">
              {userPosts.map((post) => (
                <Link
                  key={post.id}
                  href={`/post/${post.id}`}
                  className="block border border-border p-4 bg-background/40 hover:border-primary/50 transition-colors"
                >
                  <p className="text-foreground font-mono text-sm whitespace-pre-wrap mb-2">{post.content}</p>
                  <div className="flex justify-between text-xs text-muted-foreground font-mono">
                    <span>{new Date(post.createdAt).toLocaleString()}</span>
                    <span>
                      [ LIKES : {post.likesCount} ] [ COMMENTS : {post.commentsCount} ]
                    </span>
                  </div>
                </Link>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
