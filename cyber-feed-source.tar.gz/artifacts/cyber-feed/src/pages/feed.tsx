import { useState } from "react";
import { Link } from "wouter";
import { useQueryClient } from "@tanstack/react-query";
import {
  useListPosts,
  useGetTrendingHashtags,
  useCreatePost,
  useTogglePostLike,
  useDeletePost,
  getListPostsQueryKey,
  useGetCurrentAuthUser,
} from "@workspace/api-client-react";

export default function Feed() {
  const [content, setContent] = useState("");
  const queryClient = useQueryClient();

  const { data: currentUser } = useGetCurrentAuthUser();
  const { data: posts, isLoading } = useListPosts();
  const { data: trending } = useGetTrendingHashtags();

  const invalidatePosts = () => {
    queryClient.invalidateQueries({ queryKey: getListPostsQueryKey() });
  };

  const createPost = useCreatePost({
    mutation: { onSuccess: invalidatePosts },
  });
  const toggleLike = useTogglePostLike({
    mutation: { onSuccess: invalidatePosts },
  });
  const deletePost = useDeletePost({
    mutation: { onSuccess: invalidatePosts },
  });

  const handleSubmit = () => {
    if (!content.trim()) return;
    createPost.mutate(
      { data: { content: content.trim() } },
      { onSuccess: () => setContent("") },
    );
  };

  return (
    <div className="p-8 max-w-4xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-8">
      <div className="md:col-span-2 space-y-8">
        <div className="border border-primary/30 p-4 bg-card/50 backdrop-blur">
          <h3 className="text-xl font-display text-primary mb-4">[ TRANSMIT ]</h3>
          <textarea
            className="w-full bg-input border border-border p-3 text-foreground focus:border-primary outline-none transition-colors resize-none font-mono"
            rows={3}
            placeholder="Broadcast to the network..."
            value={content}
            onChange={(e) => setContent(e.target.value)}
          />
          <div className="flex justify-end mt-4">
            <button
              onClick={handleSubmit}
              disabled={!content.trim() || createPost.isPending}
              className="bg-primary text-primary-foreground px-6 py-2 font-bold hover:bg-primary/80 hover-glitch disabled:opacity-40"
            >
              {createPost.isPending ? "SENDING..." : "SEND"}
            </button>
          </div>
        </div>

        <div className="space-y-4">
          {isLoading ? (
            <div className="text-primary animate-pulse">[ LOADING TRANSMISSIONS... ]</div>
          ) : posts?.length === 0 ? (
            <div className="text-muted-foreground">[ NO SIGNALS FOUND ]</div>
          ) : (
            posts?.map((post) => (
              <div
                key={post.id}
                className="border border-border p-4 bg-card hover:border-primary/50 transition-colors group"
              >
                <div className="flex items-center justify-between mb-3">
                  <Link href={`/profile/${post.authorId}`} className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-muted border border-border flex items-center justify-center text-primary font-bold overflow-hidden">
                      {post.authorAvatarUrl ? (
                        <img src={post.authorAvatarUrl} alt="" className="w-full h-full object-cover" />
                      ) : (
                        post.authorName[0]
                      )}
                    </div>
                    <div>
                      <div className="font-bold text-primary group-hover:text-primary transition-colors">
                        {post.authorName}
                      </div>
                      <div className="text-xs text-muted-foreground">
                        {new Date(post.createdAt).toLocaleString()}
                      </div>
                    </div>
                  </Link>
                  {currentUser?.user?.id === post.authorId && (
                    <button
                      onClick={() => deletePost.mutate({ id: post.id })}
                      className="text-xs text-muted-foreground hover:text-destructive transition-colors"
                    >
                      [ DELETE ]
                    </button>
                  )}
                </div>
                <p className="text-foreground mb-4 font-mono whitespace-pre-wrap">{post.content}</p>
                <div className="flex gap-4 text-sm font-mono">
                  <button
                    onClick={() => toggleLike.mutate({ id: post.id })}
                    className={`hover:text-primary transition-colors ${post.likedByMe ? "text-primary" : "text-muted-foreground"}`}
                  >
                    [ LIKE : {post.likesCount} ]
                  </button>
                  <Link
                    href={`/post/${post.id}`}
                    className="text-muted-foreground hover:text-secondary transition-colors"
                  >
                    [ COMMENTS : {post.commentsCount} ]
                  </Link>
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      <div className="space-y-6">
        <div className="border border-secondary/30 p-4 bg-card/50">
          <h3 className="text-lg font-display text-secondary mb-4">/ TRENDING</h3>
          <ul className="space-y-2 font-mono text-sm">
            {trending?.map((t) => (
              <li
                key={t.tag}
                className="flex justify-between items-center text-muted-foreground hover:text-secondary cursor-pointer transition-colors"
              >
                <span>#{t.tag}</span>
                <span>{t.count}</span>
              </li>
            ))}
            {!trending?.length && <li className="text-muted-foreground">[ NO TRENDS ]</li>}
          </ul>
        </div>
      </div>
    </div>
  );
}
