import { Link } from "wouter";
import { useListUsers } from "@workspace/api-client-react";

export default function People() {
  const { data: users, isLoading } = useListUsers();

  return (
    <div className="p-8 max-w-4xl mx-auto">
      <h2 className="text-2xl font-display text-secondary mb-8">[ NETWORK DIRECTORY ]</h2>
      {isLoading ? (
        <div className="text-primary animate-pulse">[ SCANNING NETWORK... ]</div>
      ) : users?.length === 0 ? (
        <div className="text-muted-foreground">[ NO USERS FOUND ]</div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {users?.map((u) => (
            <Link
              key={u.id}
              href={`/profile/${u.id}`}
              className="border border-border p-4 bg-card hover:border-secondary transition-colors cursor-pointer flex items-center gap-4"
            >
              <div className="w-12 h-12 bg-muted border border-border flex items-center justify-center text-secondary font-bold overflow-hidden">
                {u.avatarUrl ? (
                  <img src={u.avatarUrl} alt="" className="w-full h-full object-cover" />
                ) : (
                  u.displayName[0]
                )}
              </div>
              <div>
                <div className="font-bold text-foreground">{u.displayName}</div>
                <div className={`text-xs font-mono ${u.isOnline ? "text-primary" : "text-muted-foreground"}`}>
                  {u.isOnline
                    ? "[ ONLINE ]"
                    : u.lastSeenAt
                      ? `[ LAST SEEN ${new Date(u.lastSeenAt).toLocaleString()} ]`
                      : "[ OFFLINE ]"}
                </div>
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
