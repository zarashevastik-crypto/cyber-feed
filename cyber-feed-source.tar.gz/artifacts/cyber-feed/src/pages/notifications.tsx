import { useQueryClient } from "@tanstack/react-query";
import {
  useListNotifications,
  useClearNotifications,
  getListNotificationsQueryKey,
} from "@workspace/api-client-react";

const TYPE_LABEL: Record<string, string> = {
  like: "LIKED YOUR POST",
  comment: "COMMENTED",
  message: "SENT A MESSAGE",
};

export default function Notifications() {
  const queryClient = useQueryClient();
  const { data: notifications, isLoading } = useListNotifications();

  const clear = useClearNotifications({
    mutation: {
      onSuccess: () =>
        queryClient.invalidateQueries({ queryKey: getListNotificationsQueryKey() }),
    },
  });

  return (
    <div className="max-w-3xl mx-auto">
      <div className="flex justify-between items-center mb-8">
        <h2 className="text-2xl font-display text-primary">[ SYSTEM ALERTS ]</h2>
        {!!notifications?.length && (
          <button
            onClick={() => clear.mutate()}
            disabled={clear.isPending}
            className="text-xs font-mono text-muted-foreground hover:text-destructive transition-colors disabled:opacity-40"
          >
            [ CLEAR LOGS ]
          </button>
        )}
      </div>
      <div className="space-y-4">
        {isLoading ? (
          <div className="text-primary animate-pulse text-center py-12">[ SCANNING... ]</div>
        ) : notifications?.length === 0 ? (
          <div className="border border-border p-4 bg-card text-muted-foreground font-mono text-sm text-center py-12">
            [ NO NEW ALERTS DETECTED ]
          </div>
        ) : (
          notifications?.map((n) => (
            <div
              key={n.id}
              className={`border p-4 bg-card font-mono text-sm flex justify-between items-center ${n.read ? "border-border text-muted-foreground" : "border-primary/50 text-foreground"}`}
            >
              <span>
                <span className="text-primary font-bold">{n.fromUserName}</span>{" "}
                {TYPE_LABEL[n.type] ?? n.type.toUpperCase()}
                {n.text ? `: ${n.text}` : ""}
              </span>
              <span className="text-xs text-muted-foreground shrink-0 ml-4">
                {new Date(n.createdAt).toLocaleString()}
              </span>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
