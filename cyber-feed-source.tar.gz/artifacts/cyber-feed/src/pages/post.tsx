import { useState } from "react";
import { Link, useParams } from "wouter";
import { useQueryClient } from "@tanstack/react-query";
import {
  useListPosts,
  useListComments,
  useCreateComment,
  useDeleteComment,
  useTogglePostLike,
  useGetCurrentAuthUser,
  getListCommentsQueryKey,
  getListPostsQueryKey,
} from "@workspace/api-client-react";

export default function PostDetail() {
  const { id } = useParams();
  const postId = Number(id);
  const [text, setText] = useState("");
  const queryClient = useQueryClient();

  const { data: currentUser } = useGetCurrentAuthUser();
  const { data: posts } = useListPosts();
  const post = posts?.find((p) => p.id === postId);

  const { data: comments, isLoading } = useListComments(postId);

  const invalidateComments = () => {
    queryClient.invalidateQueries({ queryKey: getListCommentsQueryKey(postId) });
    queryClient.invalidateQueries({ queryKey: getListPostsQueryKey() });
  };

  const createComment = useCreateComment({
    mutation: { onSuccess: invalidateComments },
  });
  const deleteComment = useDeleteComment({
    mutation: { onSuccess: invalidateComments },
  });
  const toggleLike = useTogglePostLike({
    mutation: {
      onSuccess: () => queryClient.invalidateQueries({ queryKey: getListPostsQueryKey() }),
    },
  });

  const handleReply = () => {
    if (!text.trim()) return;
    createComment.mutate(
      { id: postId, data: { text: text.trim() } },
      { onSuccess: () => setText("") },
    );
  };

  return (
    <div className="p-8 max-w-3xl mx-auto">
      <h2 className="text-2xl font-display text-primary mb-6">[ SIGNAL DECRYPTED : {id} ]</h2>
      <div className="border border-primary/50 p-6 bg-card">
        {!post ? (
          <div className="text-muted-foreground mb-8">[ SIGNAL NOT FOUND OR LOST ]</div>
        ) : (
          <div className="mb-8">
            <div className="flex items-center gap-3 mb-3">
              <Link href={`/profile/${post.authorId}`} className="flex items-center gap-3">
                <div className="w-10 h-10 bg-muted border border-border flex items-center justify-center text-primary font-bold overflow-hidden">
                  {post.authorAvatarUrl ? (
                    <img src={post.authorAvatarUrl} alt="" className="w-full h-full object-cover" />
                  ) : (
                    post.authorName[0]
                  )}
                </div>
                <div>
                  <div className="font-bold text-primary">{post.authorName}</div>
                  <div className="text-xs text-muted-foreground">
                    {new Date(post.createdAt).toLocaleString()}
                  </div>
                </div>
              </Link>
            </div>
            <p className="text-foreground font-mono whitespace-pre-wrap mb-4">{post.content}</p>
            <button
              onClick={() => toggleLike.mutate({ id: post.id })}
              className={`text-sm font-mono hover:text-primary transition-colors ${post.likedByMe ? "text-primary" : "text-muted-foreground"}`}
            >
              [ LIKE : {post.likesCount} ]
            </button>
          </div>
        )}

        <div className="border-t border-border pt-6">
          <h3 className="text-lg text-secondary mb-4">/ COMMENTS</h3>

          <div className="space-y-3 mb-6">
            {isLoading ? (
              <div className="text-primary animate-pulse text-sm">[ LOADING... ]</div>
            ) : comments?.length === 0 ? (
              <div className="text-muted-foreground text-sm">[ NO COMMENTS YET ]</div>
            ) : (
              comments?.map((c) => (
                <div key={c.id} className="border border-border p-3 bg-background/40 flex justify-between gap-4">
                  <div>
                    <div className="text-sm font-bold text-secondary">{c.authorName}</div>
                    <p className="text-foreground font-mono text-sm whitespace-pre-wrap">{c.text}</p>
                    <div className="text-xs text-muted-foreground mt-1">
                      {new Date(c.createdAt).toLocaleString()}
                    </div>
                  </div>
                  {currentUser?.user?.id === c.authorId && (
                    <button
                      onClick={() => deleteComment.mutate({ id: c.id })}
                      className="text-xs text-muted-foreground hover:text-destructive transition-colors shrink-0"
                    >
                      [ DEL ]
                    </button>
                  )}
                </div>
              ))
            )}
          </div>

          <textarea
            className="w-full bg-input border border-border p-3 text-foreground focus:border-secondary outline-none transition-colors resize-none font-mono mb-4"
            rows={2}
            placeholder="Add response..."
            value={text}
            onChange={(e) => setText(e.target.value)}
          />
          <button
            onClick={handleReply}
            disabled={!text.trim() || createComment.isPending}
            className="bg-secondary text-secondary-foreground px-4 py-2 font-bold hover:bg-secondary/80 disabled:opacity-40"
          >
            {createComment.isPending ? "SENDING..." : "REPLY"}
          </button>
        </div>
      </div>
    </div>
  );
}
